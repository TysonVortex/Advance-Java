package com.college;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/college";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Get form parameters
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String gender = request.getParameter("gender");
        String dob = request.getParameter("dob");
        String mobile = request.getParameter("mobile");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String course = request.getParameter("course");
        String city = request.getParameter("city");
        String address = request.getParameter("address");
        
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Insert query
            String sql = "INSERT INTO student_registration (student_firstname, student_lastname, gender, dob, mobile_number, email_id, password, course, city, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, firstname);
            pstmt.setString(2, lastname);
            pstmt.setString(3, gender);
            pstmt.setString(4, dob);
            pstmt.setString(5, mobile);
            pstmt.setString(6, email);
            pstmt.setString(7, password);
            pstmt.setString(8, course);
            pstmt.setString(9, city);
            pstmt.setString(10, address);
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                out.println("<html>");
                out.println("<head><title>Registration Success</title></head>");
                out.println("<body>");
                out.println("<h1>Registration Successful!</h1>");
                out.println("<table border='1'>");
                out.println("<tr><td>Name:</td><td>" + firstname + " " + lastname + "</td></tr>");
                out.println("<tr><td>Email:</td><td>" + email + "</td></tr>");
                out.println("<tr><td>Course:</td><td>" + course + "</td></tr>");
                out.println("<tr><td>Status:</td><td>Successfully Registered</td></tr>");
                out.println("</table>");
                out.println("<br><a href='login.html'>Login Now</a>");
                out.println("</body>");
                out.println("</html>");
            } else {
                out.println("<html>");
                out.println("<head><title>Registration Failed</title></head>");
                out.println("<body>");
                out.println("<h1>Registration Failed!</h1>");
                out.println("<p>Please try again.</p>");
                out.println("<a href='registration.html'>Go Back</a>");
                out.println("</body>");
                out.println("</html>");
            }
            
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            out.println("<html>");
            out.println("<head><title>Error</title></head>");
            out.println("<body>");
            out.println("<h1>Error!</h1>");
            out.println("<p>Error: " + e.getMessage() + "</p>");
            out.println("<a href='registration.html'>Go Back</a>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
}
-- Create Database
CREATE DATABASE IF NOT EXISTS college;

-- Use the database
USE college;

-- Create student_registration table
CREATE TABLE IF NOT EXISTS student_registration (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_firstname VARCHAR(50) NOT NULL,
    student_lastname VARCHAR(50) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    dob VARCHAR(20) NOT NULL,
    mobile_number VARCHAR(15) NOT NULL,
    email_id VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    city VARCHAR(50) NOT NULL,
    address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data (optional)
INSERT INTO student_registration 
(student_firstname, student_lastname, gender, dob, mobile_number, email_id, password, course, city, address) 
VALUES 
('John', 'Doe', 'Male', '01/01/2000', '9876543210', 'john@email.com', 'password123', 'Computer Science', 'Mumbai', '123 Main Street'),
('Jane', 'Smith', 'Female', '15/05/1999', '9876543211', 'jane@email.com', 'password456', 'Information Technology', 'Delhi', '456 Park Avenue');

-- Display table structure
DESCRIBE student_registration;

-- Display all records
SELECT * FROM student_registration;
package com.college;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/college";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Get form parameters
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to database
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Query to check user credentials
            String sql = "SELECT * FROM student_registration WHERE email_id = ? AND password = ?";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                // Create session and store user email
                HttpSession session = request.getSession();
                session.setAttribute("userEmail", email);
                
                // Display user login details
                out.println("<html>");
                out.println("<head><title>Login Success</title></head>");
                out.println("<body>");
                out.println("<h1>Login Successful!</h1>");
                out.println("<h2>User Login Details:</h2>");
                out.println("<table border='1'>");
                out.println("<tr><td>Student ID:</td><td>" + rs.getInt("student_id") + "</td></tr>");
                out.println("<tr><td>First Name:</td><td>" + rs.getString("student_firstname") + "</td></tr>");
                out.println("<tr><td>Last Name:</td><td>" + rs.getString("student_lastname") + "</td></tr>");
                out.println("<tr><td>Gender:</td><td>" + rs.getString("gender") + "</td></tr>");
                out.println("<tr><td>Date of Birth:</td><td>" + rs.getString("dob") + "</td></tr>");
                out.println("<tr><td>Mobile Number:</td><td>" + rs.getString("mobile_number") + "</td></tr>");
                out.println("<tr><td>Email ID:</td><td>" + rs.getString("email_id") + "</td></tr>");
                out.println("<tr><td>Course:</td><td>" + rs.getString("course") + "</td></tr>");
                out.println("<tr><td>City:</td><td>" + rs.getString("city") + "</td></tr>");
                out.println("<tr><td>Address:</td><td>" + rs.getString("address") + "</td></tr>");
                out.println("<tr><td>Session Email:</td><td>" + session.getAttribute("userEmail") + "</td></tr>");
                out.println("</table>");
                out.println("<br><a href='logout'>Logout</a>");
                out.println("</body>");
                out.println("</html>");
                
            } else {
                out.println("<html>");
                out.println("<head><title>Login Failed</title></head>");
                out.println("<body>");
                out.println("<h1>Login Failed!</h1>");
                out.println("<p>Invalid email or password. Please try again.</p>");
                out.println("<a href='login.html'>Go Back to Login</a><br>");
                out.println("<a href='registration.html'>Sign up (Register new account)</a>");
                out.println("</body>");
                out.println("</html>");
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            out.println("<html>");
            out.println("<head><title>Error</title></head>");
            out.println("<body>");
            out.println("<h1>Error!</h1>");
            out.println("<p>Error: " + e.getMessage() + "</p>");
            out.println("<a href='login.html'>Go Back</a>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
}